# Car-Showroom-Management-System
The Car Showroom Management System is a software solution that helps manage vehicle inventory, customer details, sales, and service bookings. It streamlines operations, improves sales tracking, and enhances customer service through an easy-to-use interface.
Navigation Menu
SHOWROOM-MANAGEMENT-SYSTEM


A Java-based program called the Showroom Management System was created to optimize a car dealership's operations. Through the use of Object-Oriented Programming (OOP) principles, the system effectively controls the interactions between vehicles, staff, and the showroom. By offering a single platform for data storage and retrieval, this program minimizes errors and human labor.

Car Management, Employee Management, and Showroom Management are the three main elements that make up the system. Each vehicle's brand, model, year, price, and availability are all stored in detail in the Car Management module. Employee data, including name, ID, role, and contact details, are tracked by the Employee Management module. The location, capacity, and inventory of the showroom are all kept up to date by the Showroom Management module.

The system makes sure that every entity (car, employee, showroom) isolates its own data and behavior by applying OOP concepts like encapsulation. This design is perfect for showrooms of different sizes since it allows for effective data management, scalability, and adaptability.

                                                        PROJECT STRUCTURE
The project is organized into five distinct parts: one interface and four classes, each with a specific role in managing showroom data.

utility Interface Purpose: This interface acts as a contract for any class that needs to handle its own details. It ensures that all implementing classes will have both a get_details() method (to display information) and a set_details() method (to input information). Significance: It promotes polymorphism, meaning you could potentially treat Showroom, Employees, and Cars objects uniformly if you were to store them in a collection of utility types.
Showroom Class Purpose: This class models a physical car showroom. It holds basic information about the showroom itself. Implements utility: This means it provides concrete implementations for get_details() and set_details(), allowing you to input and display showroom-specific data like its name, location, manager, and the number of employees and cars. Attributes: showroom_name, showroom_location, total_employees, total_cars_in_stock, and manager_name.
Employees Class Purpose: This class represents an employee working in a showroom. Extends Showroom: This is an important design choice. By extending Showroom, Employees inherits all the public and protected attributes and methods of Showroom. This means an Employee object directly has access to showroom_name, for instance. Implements utility: It provides its own get_details() and set_details() methods to handle employee-specific data, such as staff_id (which you smartly generate using UUID.randomUUID()), staff_name, staff_age, and staff_department. When setting details, it also asks for the showroom_name to associate the employee.
Cars Class Purpose: This class models a car available in a showroom's inventory. Extends Showroom: Similar to Employees, Cars also inherits from Showroom. This gives it access to total_cars_in_stock from the Showroom class, which you increment when a new car is added. Implements utility: It implements get_details() and set_details() to manage car-specific attributes like vehicle_name, car_exterior_color, car_fuel_type, car_price, car_type, and car_transmission_mode.
Main Class Purpose: This is the entry point of your entire application. It acts as the main controller for the showroom management system. main_menu() method: Displays the interactive menu to the user, listing options like adding/getting showrooms, employees, and cars. main() method: Initializes a Scanner object to take user input. Declares fixed-size arrays (Showroom[], Employees[], Cars[]) to store up to 5 objects of each type. Uses counters (showroom_counter, employees_counter, car_counter) to keep track of how many items have been added to each array. It contains the main program loop (while(choice!=0)), which continuously displays the menu and processes user choices using a switch statement. User Interaction: When a user chooses to add (1, 2, or 3), it creates a new object of the respective type and calls its set_details() method. When a user chooses to get (4, 5, or 6), it iterates through the stored array and calls the get_details() method for each object. It handles the menu navigation, allowing users to go back to the main menu or exit the application. Showroom Management System
Project Overview
This project is a simple, console-based application developed in Java for managing a car showroom's essential data. It provides functionalities to add, view, and organize information related to showrooms, their employees, and the cars in their inventory. The system is designed with a clear, menu-driven interface for ease of use.

Core Feature Implementation
The application is built around the following core functionalities, providing a comprehensive management experience for a showroom:

Showroom Management:

Add New Showroom: Allows users to input and register details for a new showroom, including its unique name, physical location, the manager's name, the total number of employees, and the initial count of cars in stock.
View All Showrooms: Displays a detailed list of all showrooms currently registered in the system, presenting all their stored attributes.
Employee Management:

Add New Employee: Facilitates the entry of new employee details such as their full name, age, department, and the showroom they are associated with. Each employee is automatically assigned a unique ID upon creation.
View All Employees: Presents a comprehensive list of all employees, showing their unique ID, name, age, department, and the showroom where they work.
Car Inventory Management:

Add New Car: Enables the addition of new car models to the inventory. Users can specify the car's name (model), exterior color, fuel type (Petrol/Diesel), price, general car type (e.g., BMW, Mercedes, Hatchback), and transmission mode (Automatic/Manual). Adding a car automatically increments the general total_cars_in_stock count (inherited from the Showroom context).
View All Cars: Lists all cars currently in the inventory with their respective details.
Error Handling & Robustness
To ensure the application's stability and a smooth user experience, robust error handling mechanisms have been implemented:

Input Type Validation: All numeric inputs (e.g., total_employees, staff_age, car_price) are wrapped in try-catch blocks to gracefully handle InputMismatchException. If a user enters non-numeric data where a number is expected, an informative error message is displayed, and the user is re-prompted for valid input, preventing application crashes.
Graceful Termination: The application allows users to exit cleanly from any sub-menu or the main menu by entering 0, ensuring controlled program termination.
Integration of Components
The project's architecture promotes modularity and clear interaction between different components:

Centralized Control (Main class): The Main class serves as the application's orchestrator, managing the main menu, handling user input, and coordinating interactions between Showroom, Employees, and Cars objects.
Interface-Driven Consistency (utility interface): The utility interface defines a common contract (set_details(), get_details()) that Showroom, Employees, and Cars classes adhere to. This ensures a consistent approach to data input and retrieval across different entities.
Conceptual Association (Inheritance for simplicity): Employees and Cars currently extend Showroom to simplify the association of these entities with a showroom name and to allow Cars to directly increment total_cars_in_stock. While this is a form of integration, for future enhancements, a composition-based approach (where Employees and Cars contain a reference to a Showroom) would offer a more flexible and logically sound representation of real-world relationships.
Event Handling & Processing
As a console-based application, user interactions are managed through a responsive menu-driven system. There are no graphical user interface (GUI) events in this current implementation.

Menu-Driven Interaction: The main_menu() method presents clear options to the user.
Choice Processing: User input (menu options) is captured using java.util.Scanner and processed efficiently by a switch statement within the main application loop. This directs the program flow to the appropriate functionality based on the user's selection (e.g., creating a new showroom, displaying employee details).
Continuous Loop: The application remains active in a loop, continuously re-presenting the menu and accepting new choices until the user explicitly selects the exit option (0).
Data Validation
Input validation is implemented to maintain data integrity and ensure that the stored information is meaningful:

Type Validation: As mentioned in "Error Handling," inputs are strictly validated to ensure they match the expected data type (e.g., preventing text input for numeric fields).
Range Validation (Example for numeric inputs):
For total_employees and staff_age, input is validated to ensure it's a positive number.
For car_price, input is validated to be a positive value.
Enumerated Value Validation (Example):
car_fuel_type input is validated to accept only "PETROL" or "DIESEL" (case-insensitive conversion is applied before validation).
Similar validation can be extended for car_type or car_transmission_mode if a fixed set of options is desired.
String Emptiness Check (Optional but good practice): Can be extended to ensure critical string fields (like names) are not left empty.
Code Quality and Innovative Features
The project emphasizes clean, readable, and maintainable code, incorporating thoughtful design elements:

Object-Oriented Design: The application is structured using classes (Showroom, Employees, Cars) and an interface (utility), demonstrating a fundamental understanding of OOP principles like abstraction, encapsulation, and inheritance (though acknowledging areas for potential refactoring to composition for stronger design).
Modularity: Functionalities are logically separated into distinct classes and methods, making the codebase easier to understand and manage.
Readability: Meaningful variable and method names (showroom_name, get_details, main_menu) are used to enhance code clarity.
Code Documentation: (Add Javadoc comments to your code files!) The code includes inline comments and can be further enhanced with Javadoc comments for classes, methods, and complex logic, explaining their purpose, parameters, and return values.
Unique Identifier Generation: Employee IDs are automatically generated using java.util.UUID, ensuring each employee record has a globally unique identifier without manual input.
Clear User Interface: The console output is formatted with banners and clear prompts, providing a user-friendly experience for a CLI application.
